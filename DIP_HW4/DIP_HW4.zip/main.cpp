//
//  main.cpp
//  DIP_HW2
//
//  Created by 王瀚磊 on 2016/10/19.
//  Copyright © 2016年 王瀚磊. All rights reserved.
//

#include <iostream>
#include <opencv.hpp>


using namespace cv;
using namespace std;

double pixelDistance(double , double );
double high_gaussianCoeff(double , double , double );
double low_gaussianCoeff(double , double , double );
double high_butterworthCoeff(double , double , double );
double low_butterworthCoeff(double , double , double );
Mat createGaussianHighPassFilter(Size , float );
Mat createGaussianLowPassFilter(Size , float );
Mat createIdealHighPassFilter(Size , float );
Mat createIdealLowPassFilter(Size , float );
Mat createButterworthLowPassFilter(Size , float );
Mat createButterworthHighPassFilter(Size , float );
Mat shift(Mat );

/*
       ./DIP_HW4 input_source_path output_path filter_type
 */

int main(int argc, char * argv[]){
    
    string input_path = argv[1];
    string output_path = argv[2];
    
    int filter_type = stoi(argv[3]);
    if(input_path.empty())
    {cout<<"please enter input image path"<<endl;
        return 0;}
    if(output_path.empty())
    {cout<<"please enter output path"<<endl;
        return 0;}
    if(filter_type>=6||filter_type<=0)
    {cout<<"please enter 1~4 filter type"<<endl;
        return 0;}
    
    Mat inputImg = imread(input_path, CV_LOAD_IMAGE_GRAYSCALE);
    Mat padded;
    int m = getOptimalDFTSize(inputImg.rows);  //m為大於等於inputImg.rows裡的最小值，且須為2、3、5的次方相乘
    int n = getOptimalDFTSize(inputImg.cols);
    copyMakeBorder(inputImg, padded, 0, m-inputImg.rows, 0, n-inputImg.cols, BORDER_CONSTANT, Scalar::all(0)); //為了效率，所以對影像邊界拓展
    
    Mat planes[] = {Mat_<float>(padded), Mat::zeros(padded.size(), CV_32F)};
    Mat complexImg;
    merge(planes, 2, complexImg);
    dft(complexImg, complexImg);
    
    split(complexImg, planes);                  //分離通道，planes[0]為實數部分，planes[1]為虛數部分
    magnitude(planes[0], planes[1], planes[0]); //planes[0] = sqrt((planes[0])^2 + (planes[1])^2)
    Mat magI = planes[0];
    magI += Scalar::all(1);                     //magI = log(1+planes[0])
    log(magI, magI);
    
    Mat filter;
    switch (filter_type) {
        case 1:
        {filter = createIdealHighPassFilter(Size(complexImg.cols,complexImg.rows), 30.0);
            break;}
        case 2:
        {filter = createIdealLowPassFilter(Size(complexImg.cols,complexImg.rows), 30.0);
            break;}
        case 3:
        {filter = createGaussianHighPassFilter(Size(complexImg.cols,complexImg.rows), 30.0);
            break;}
        case 4:
        {filter = createGaussianLowPassFilter(Size(complexImg.cols,complexImg.rows), 30.0);
            break;}
        case 5:
        {filter = createButterworthHighPassFilter(Size(complexImg.cols,complexImg.rows), 30.0);
            break;}
        case 6:
        {filter = createButterworthLowPassFilter(Size(complexImg.cols,complexImg.rows), 30.0);
            break;}
            
    }
    complexImg = shift(complexImg);
    for(int channel=0;channel<complexImg.channels();channel++){
        for(int i=0;i<complexImg.rows;i++){
            for(int j=0;j<complexImg.cols;j++){
                complexImg.at<Vec2f>(i,j)[channel] = complexImg.at<Vec2f>(i,j)[channel] * filter.at<float>(i,j);
            }}}
    complexImg = shift(complexImg);
    
    

    
    //將區塊重排，讓原點在影像的中央
    magI = shift(magI);

    normalize(magI, magI, 0, 1, CV_MINMAX);
    
    Mat magI_mask;
    magI.copyTo(magI_mask);
    for(int i=0;i<magI.rows;i++){
        for(int j=0;j<magI.cols;j++){
            magI_mask.at<float>(i,j) = magI_mask.at<float>(i,j) * filter.at<float>(i,j);
        }}
   
    

    //逆向傅立葉轉換
    Mat ifft;
    idft(complexImg,ifft,DFT_REAL_OUTPUT);
    normalize(ifft,ifft,0,1,CV_MINMAX);
    
    imshow("spectrum", magI);
    magI.convertTo(magI, CV_8U,255);
    imwrite(output_path + "spectrum.jpg", magI);
    
    imshow("spectrum with mask", magI_mask);
    magI_mask.convertTo(magI_mask, CV_8U,255);
    imwrite(output_path + "spectrum_with_mask.jpg", magI_mask);
    
    imshow("filter",filter);
    filter.convertTo(filter, CV_8U,255);
    imwrite(output_path + "filter.jpg", filter);
    
    imshow("invert result",ifft);
    ifft.convertTo(ifft, CV_8U,255);
    imwrite(output_path + "inverse_result.jpg", ifft);

    //waitKey();
    
    return 0;    
}

double pixelDistance(double u, double v)
{
    return cv::sqrt(u*u + v*v);
}

double high_gaussianCoeff(double u, double v, double d0)
{
    double d = pixelDistance(u, v);
    return 1.0 - cv::exp((-d*d) / (2*d0*d0));
}

double low_gaussianCoeff(double u, double v, double d0)
{
    double d = pixelDistance(u, v);
    return cv::exp((-d*d) / (2*d0*d0));
}

cv::Mat createGaussianHighPassFilter(cv::Size size, float cutoffInPixels)
{
    Mat ghpf(size, CV_32F);
    
    cv::Point center(size.width / 2, size.height / 2);
    
    for(int u = 0; u < ghpf.rows; u++)
    {
        for(int v = 0; v < ghpf.cols; v++)
        {
            ghpf.at<float>(u, v) = high_gaussianCoeff(u - center.y, v - center.x, cutoffInPixels);
        }
    }
    
    return ghpf;
}

cv::Mat createGaussianLowPassFilter(cv::Size size, float cutoffInPixels)
{
    Mat ghpf(size, CV_32F);
    
    cv::Point center(size.width / 2, size.height / 2);
    
    for(int u = 0; u < ghpf.rows; u++)
    {
        for(int v = 0; v < ghpf.cols; v++)
        {
            ghpf.at<float>(u, v) = low_gaussianCoeff(u - center.y, v - center.x, cutoffInPixels);
        }
    }
    
    return ghpf;
}

Mat shift(Mat magI){
    magI = magI(Rect(0, 0, magI.cols & -2, magI.rows & -2));  //令邊長為偶數
    int cx = magI.cols/2;
    int cy = magI.rows/2;
    
    Mat q0(magI, Rect(0, 0, cx, cy));
    Mat q1(magI, Rect(cx, 0, cx, cy));
    Mat q2(magI, Rect(0, cy, cx, cy));
    Mat q3(magI, Rect(cx, cy, cx, cy));
    
    
    Mat tmp;
    q0.copyTo(tmp);
    q3.copyTo(q0);
    tmp.copyTo(q3);
    q1.copyTo(tmp);
    q2.copyTo(q1);
    tmp.copyTo(q2);
    
    return magI;
}

Mat createIdealHighPassFilter(Size size, float cutoffInPixels){
    Mat ilpf = Mat::ones(size, CV_32F);
    
    int cx = size.width/2;
    int cy = size.height/2;
    
    for(int i = 0 ; i < size.width ; i++){
        for(int j = 0 ; j < size.height ; j++)
        {
            if(sqrt(pow(i-cx,2)+pow(j-cy,2))<=cutoffInPixels)
                ilpf.at<float>(j,i) = 0;
        }
    }
    return ilpf;
}


Mat createIdealLowPassFilter(Size size, float cutoffInPixels){
    Mat ihpf = Mat::zeros(size, CV_32F);
    
    int cx = size.width/2;
    int cy = size.height/2;
    
    for(int i = 0 ; i < size.width ; i++){
        for(int j = 0 ; j < size.height ; j++)
        {
            if(sqrt(pow(i-cx,2)+pow(j-cy,2))<=cutoffInPixels)
                ihpf.at<float>(j,i) = 1;
        }
    }
    return ihpf;

    
}


double low_butterworthCoeff(double u, double v, double d0)
{
    double d = pixelDistance(u, v);
    return 1/(1+(pixelDistance(u, v)/d0)*(pixelDistance(u, v)/d0));
}

double high_butterworthCoeff(double u, double v, double d0)
{
    double d = pixelDistance(u, v);
    return 1/(1+(d0/pixelDistance(u, v))*(d0/pixelDistance(u, v)));
}

cv::Mat createButterworthLowPassFilter(cv::Size size, float cutoffInPixels)
{
    Mat blpf(size, CV_32F);
    
    cv::Point center(size.width / 2, size.height / 2);
    
    for(int u = 0; u < blpf.rows; u++)
    {
        for(int v = 0; v < blpf.cols; v++)
        {
            blpf.at<float>(u, v) = low_butterworthCoeff(u - center.y, v - center.x, cutoffInPixels);
        }
    }
    
    return blpf;
}


cv::Mat createButterworthHighPassFilter(cv::Size size, float cutoffInPixels)
{
    Mat bhpf(size, CV_32F);
    
    cv::Point center(size.width / 2, size.height / 2);
    
    for(int u = 0; u < bhpf.rows; u++)
    {
        for(int v = 0; v < bhpf.cols; v++)
        {
            bhpf.at<float>(u, v) = high_butterworthCoeff(u - center.y, v - center.x, cutoffInPixels);
        }
    }
    
    return bhpf;
}









