﻿#include<opencv.hpp>
#include <opencv2\imgproc.hpp>
#include<highgui.hpp>
using namespace cv;
using namespace std;

int main()
{
        VideoCapture video("lib.avi");
        VideoWriter writer;
        Mat src;
        video >> src;
        writer.open("lib_test.avi", CV_FOURCC('M', 'J', 'P', 'G'), 30, src.size());
	
		Mat src_temp = src.clone();
		Mat imageGray;
		cvtColor(src, imageGray, CV_BGR2GRAY);

		int kernel_size = 3;
		Mat grad_x, grad_y;
		Mat abs_grad_x, abs_grad_y;
		Sobel(imageGray, grad_x, CV_64F, 1, 0, kernel_size, 1, 0, BORDER_REPLICATE);
		convertScaleAbs(grad_x, abs_grad_x);  //轉成CV_8U
		Sobel(imageGray, grad_y, CV_64F, 0, 1, kernel_size, 1, 0, BORDER_REPLICATE);
		convertScaleAbs(grad_y, abs_grad_y);
		Mat dst(grad_x.size(), grad_x.type());
		addWeighted(abs_grad_x, 0.5, abs_grad_y, 0.5, 0, dst);

		int Block_size = 20;
		Mat opening(dst.size(), dst.type());
		Mat _result(dst.size(), dst.type());
		Mat element(Size(Block_size, Block_size), CV_8U, Scalar(1));
		morphologyEx(dst, opening, MORPH_OPEN, element);
		morphologyEx(opening, _result, MORPH_CLOSE, element);

		adaptiveThreshold(_result, _result, 255, ADAPTIVE_THRESH_MEAN_C, THRESH_BINARY, 11, 0);

		//查找輪廓
		vector<vector<Point>> contours;
		vector<Vec4i> hierarchy;
		findContours(_result, contours, hierarchy, CV_RETR_EXTERNAL, CHAIN_APPROX_SIMPLE, Point());
		Mat imageContours = Mat::zeros(src.size(), CV_8UC1);
		Mat  markers(src.size(), CV_32S);
		markers = Scalar::all(0);
		int index = 0;
		int compCount = 0;
		for (; index >= 0; index = hierarchy[index][0], compCount++)
		{
			//對markers進行標記，對不同區域的輪廓進行標號，相當於設置注水點，有多少輪廓就有多少注水點
			drawContours(markers, contours, index, Scalar::all(compCount + 1), 3, 8, hierarchy);
			drawContours(imageContours, contours, index, Scalar(255), 3, 8, hierarchy);
		}

		Mat marksShows;
		convertScaleAbs(markers, marksShows);

		watershed(src, markers);

		Mat afterWatershed;
		convertScaleAbs(markers, afterWatershed);

		markers.convertTo(markers, CV_8U, 255);

		Mat labels; //labels of commponents
		float max_label_num = connectedComponents(markers, labels, 4);

		vector<Vec3b> color_Array(max_label_num, Vec3b(1000, 1000, 1000));

		for (int i = 0; i < labels.rows; i++){
			for (int j = 0; j < labels.cols; j++)
			{
				int num = labels.at<int>(i, j);
				if (num == 0)
				{
					src.at<Vec3b>(i, j)[0] = 255;
					src.at<Vec3b>(i, j)[1] = 255;
					src.at<Vec3b>(i, j)[2] = 255;
				}
				else{
					if (color_Array[num][0] == (uchar)1000)
					{
						color_Array[num] = src.at<Vec3b>(i, j);
					}
					else
					{
						src.at<Vec3b>(i, j) = color_Array[num];
					}
				}
			}
		}
		addWeighted(src_temp, 0.5, src, 0.5, 0, src);
		imwrite("lib.JPG",src);

	return 0;
}
