﻿#include "opencv2/core/core.hpp"
#include "opencv2/highgui/highgui.hpp"
#include "opencv2/imgproc/imgproc.hpp"
#include <opencv2/photo.hpp>
#include <stdio.h>
#include <iostream>
#include <cmath>

using namespace cv;
using namespace std;

int main(int argc, char* argv[])
{
	Mat src = imread("lib.png");
	Mat result(src.size(), CV_32FC3);
	src.convertTo(result, CV_32FC3);
	Mat img(src.size(), CV_32FC3);
	src.convertTo(img, CV_32FC3);

	Mat kernel;
	Point anchor = Point(-1, -1);
	double delta = 0;
	int ddepth = -1;
	int _kernel_size = 3;

	Mat K_x;
	Mat K_y;

	K_x = Mat::zeros(_kernel_size, _kernel_size, CV_32F);
	K_y = Mat::zeros(_kernel_size, _kernel_size, CV_32F);

	float p = 3, q = 0;

	//Sobel Egde
	K_x.at<float>(0, 0) = -1;  K_x.at<float>(0, 1) = 0; K_x.at<float>(0, 2) = 1;
	K_x.at<float>(1, 0) = -p;  K_x.at<float>(1, 1) = q;  K_x.at<float>(1, 2) = p;
	K_x.at<float>(2, 0) = -1;  K_x.at<float>(2, 1) = 0;  K_x.at<float>(2, 2) = 1;

	K_y.at<float>(0, 0) = -1; K_y.at<float>(0, 1) = -p; K_y.at<float>(0, 2) = -1;
	K_y.at<float>(1, 0) = 0;  K_y.at<float>(1, 1) = q;  K_y.at<float>(1, 2) = 0;
	K_y.at<float>(2, 0) = 1;  K_y.at<float>(2, 1) = p;  K_y.at<float>(2, 2) = 1;

	Mat Image_x(src.size(), CV_32FC3);
	Mat Image_y(src.size(), CV_32FC3);

	cv::filter2D(img, Image_x, ddepth, K_x);
	cv::filter2D(img, Image_y, ddepth, K_y);

	float alpha = 0.5;

	result = alpha*abs(Image_x) + (1 - alpha)*abs(Image_y);

	result = result / 255;

	for (int k = 0; k < result.channels(); k++)
	{
		for (int i = 0; i < result.rows; i++)
		{
			for (int j = 0; j < result.cols; j++)
			{
				result.at<Vec3f>(i, j)[k] = 1.0 - result.at<Vec3f>(i, j)[k];   // 每一个像素反转  
			}
		}
	}
	result.convertTo(result, CV_8UC3, 255);
	addWeighted(src, 0.7, result, 0.3, 0, result);
	
	Mat yuv = result.clone();
	
	Mat yuv;
	cvtColor(result, yuv, CV_BGR2HLS);
	vector<Mat> channels2;
	split(yuv, channels2);
	equalizeHist(channels2[2], channels2[2]);
	merge(channels2, yuv);
	cvtColor(yuv, yuv, CV_HLS2BGR);
	

	Mat cloud = imread("cloud.jpg");

	Mat imageGray;
	cvtColor(src, imageGray, CV_BGR2GRAY);

	Mat mask;
	Canny(imageGray, mask, 30, 100);
	GaussianBlur(mask, mask, Size(15, 15), 3);
	
	int Block_size = 3;
	Mat _element(Size(Block_size, Block_size), CV_8U, Scalar(1));

	for (int i = 0; i < 8; i++){
		dilate(mask, mask, _element, Point(-1, -1));
	}

	Block_size = 5;
	Mat element(Size(Block_size, Block_size), CV_8U, Scalar(1));

	morphologyEx(mask, mask, MORPH_OPEN, element);
	morphologyEx(mask, mask, MORPH_CLOSE, element);

	Block_size = 3;
	Mat __element(Size(Block_size, Block_size), CV_8U, Scalar(1));

	for (int i = 0; i < 5; i++){
		erode(mask, mask, __element, Point(-1, -1));
	}

	mask.convertTo(mask, CV_8U, 255);
	imshow("mask", mask);
	
	Mat _result;
	seamlessClone(yuv, cloud, mask, Point(yuv.cols / 2, yuv.rows / 2), _result, 1);
	imshow("blend result", _result);
	imwrite("blend.jpg", _result);
	waitKey();
}
