

#include <iostream>
#include <cstring>

#include "opencv2/bioinspired.hpp"
#include "opencv2/imgcodecs.hpp"
#include "opencv2/videoio.hpp"
#include "opencv2/highgui.hpp"

static void help(std::string errorMessage)
{
    std::cout<<"Program init error : "<<errorMessage<<std::endl;
    std::cout<<"\nProgram call procedure : retinaDemo [processing mode] [Optional : media target] [Optional LAST parameter: \"log\" to activate retina log sampling]"<<std::endl;
    std::cout<<"\t[processing mode] :"<<std::endl;
    std::cout<<"\t -image : for still image processing"<<std::endl;
    std::cout<<"\t -video : for video stream processing"<<std::endl;
    std::cout<<"\t[Optional : media target] :"<<std::endl;
    std::cout<<"\t if processing an image or video file, then, specify the path and filename of the target to process"<<std::endl;
    std::cout<<"\t leave empty if processing video stream coming from a connected video device"<<std::endl;
    std::cout<<"\t[Optional : activate retina log sampling] : an optional last parameter can be specified for retina spatial log sampling"<<std::endl;
    std::cout<<"\t set \"log\" without quotes to activate this sampling, output frame size will be divided by 4"<<std::endl;
    std::cout<<"\nExamples:"<<std::endl;
    std::cout<<"\t-Image processing : ./retinaDemo -image lena.jpg"<<std::endl;
    std::cout<<"\t-Image processing with log sampling : ./retinaDemo -image lena.jpg log"<<std::endl;
    std::cout<<"\t-Video processing : ./retinaDemo -video myMovie.mp4"<<std::endl;
    std::cout<<"\t-Live video processing : ./retinaDemo -video"<<std::endl;
    std::cout<<"\nPlease start again with new parameters"<<std::endl;
}

int main(int argc, char* argv[])
{
    
    
    if (argc<2)
    {
        help("bad number of parameter");
        return -1;
    }
    
    bool useLogSampling = !strcmp(argv[argc-1], "log");
    
    std::string inputMediaType=argv[1];
    
    
    cv::Mat inputFrame;
    cv::VideoCapture videoCapture;
    
    
    
    if (!strcmp(inputMediaType.c_str(), "-image") && argc >= 3)
    {
        std::cout<<"RetinaDemo: processing image "<<argv[2]<<std::endl;
        inputFrame = cv::imread(std::string(argv[2]), 1);
    }else
        if (!strcmp(inputMediaType.c_str(), "-video"))
        {
            if (argc == 2 || (argc == 3 && useLogSampling))
            {
                videoCapture.open(0);
            }else
            {
                std::cout<<"RetinaDemo: processing video stream "<<argv[2]<<std::endl;
                videoCapture.open(argv[2]);
            }
            
            
            videoCapture>>inputFrame;
        }else
        {
            help("bad command parameter");
            return -1;
        }
    
    if (inputFrame.empty())
    {
        help("Input media could not be loaded, aborting");
        return -1;
    }
    
    
    try
    {
        cv::Ptr<cv::bioinspired::Retina> myRetina;
        
        if (useLogSampling)
        {
            myRetina = cv::bioinspired::createRetina(inputFrame.size(), true, cv::bioinspired::RETINA_COLOR_BAYER, true, 1.0, 2.0);
        }
        else
            myRetina = cv::bioinspired::createRetina(inputFrame.size());
        
        
        myRetina->write("/Users/halley/Desktop/RetinaDefaultParameters.xml");   
        
        myRetina->setup("/Users/halley/Desktop/RetinaSpecificParameters.xml");
        myRetina->clearBuffers();
        
        cv::Mat retinaOutput_parvo;
        cv::Mat retinaOutput_magno;
        
//        cv::VideoWriter videoWriter;
//        videoWriter.open("/Users/halley/Desktop/VideoTest.avi", CV_FOURCC('M', 'J', 'P', 'G'), 30, inputFrame.size());

        
        bool continueProcessing=true;
        while(continueProcessing)
        {
            
            if (videoCapture.isOpened())
                videoCapture>>inputFrame;
            
            myRetina->run(inputFrame);
            myRetina->getParvo(retinaOutput_parvo);
//            myRetina->getMagno(retinaOutput_magno);
//            videoWriter.write(retinaOutput_parvo);

//            cv::imshow("retina input", inputFrame);
            cv::imshow("Retina Parvo", retinaOutput_parvo);
//            cv::imshow("Retina Magno", retinaOutput_magno);
            
            cv::waitKey(5);
            
        }
    }catch(cv::Exception e)
    {
        std::cerr<<"Error using Retina : "<<e.what()<<std::endl;
    }
    
    std::cout<<"Retina demo end"<<std::endl;
    
    return 0;
}
