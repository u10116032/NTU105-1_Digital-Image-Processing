﻿#include "opencv2/core/core.hpp"
#include "opencv2/highgui/highgui.hpp"
#include "opencv2/imgproc/imgproc.hpp"
#include <opencv2/photo.hpp>
#include <stdio.h>
#include <iostream>
#include <cmath>

using namespace cv;
using namespace std;

int main(int argc, char* argv[])
{
	Mat src = imread("lib.png");
	Mat blur;
	bilateralFilter(src, blur, 5, 20, 20);
	cvtColor(blur, blur, CV_BGR2HSV_FULL);
	vector<Mat> channels2;
	split(blur, channels2);
	equalizeHist(channels2[1], channels2[1]);
	merge(channels2, blur);
	cvtColor(blur, blur, CV_HSV2BGR_FULL);
	imshow("yuv", blur);

	Mat result,imageGray;
	cvtColor(src, imageGray, CV_BGR2GRAY);
	imageGray.convertTo(imageGray, -1, 1.1, 0);
	GaussianBlur(imageGray, imageGray, Size(5, 5), 0, 0);
	//Canny(imageGray,result,100,150);
	//threshold(result, result, 128, 255, THRESH_BINARY_INV);
	//imshow("canny",result);
	
	int kernel_size = 3;
	Mat grad_x, grad_y;
	Mat abs_grad_x, abs_grad_y;
	Sobel(imageGray, grad_x, CV_64F, 1, 0, kernel_size, 1, 0, BORDER_CONSTANT);
	convertScaleAbs(grad_x, abs_grad_x);  //轉成CV_8U
	Sobel(imageGray, grad_y, CV_64F, 0, 1, kernel_size, 1, 0, BORDER_CONSTANT);
	convertScaleAbs(grad_y, abs_grad_y);
	Mat dst(grad_x.size(), grad_x.type());
	addWeighted(abs_grad_x, 0.5, abs_grad_y, 0.5, 0, dst);
	threshold(dst,result,128,255,CV_THRESH_BINARY_INV|THRESH_OTSU);
	imshow("closing", result);

	Mat _result(src.size(), src.type());
	for (int i = 0; i < result.rows; i++)
	{
		for (int j = 0; j < result.cols; j++)
		{
			uchar color = result.at<uchar>(i, j);
			if (color != 0){
				_result.at<Vec3b>(i, j) = blur.at<Vec3b>(i, j);
			}
			else{
				_result.at<Vec3b>(i, j)[0] = 0;
				_result.at<Vec3b>(i, j)[1] = 0;
				_result.at<Vec3b>(i, j)[2] = 0;
			}
		}
	}
	//_result.convertTo(_result, -1, 1.1, 0);
	addWeighted(src, 0.5, _result, 0.5, 0, _result);
	cvtColor(_result, _result, CV_BGR2HSV_FULL);
	vector<Mat> channels3;
	split(_result, channels3);
	equalizeHist(channels3[1], channels3[1]);
	merge(channels3, _result);
	cvtColor(_result, _result, CV_HSV2BGR_FULL);
	imshow("result", _result);

	waitKey();
}
